Manopt is a Matlab toolbox for optimization on manifolds.

Manopt is copyright � 2013 by Nicolas Boumal (nicolasboumal@gmail.com) and is distributed under the terms of the GNU General Public License (GPL) version 3 (or later). See the files LICENSE.TXT, COPYING.TXT and CREDITS.TXT.

Documentation and updates are available online: http://www.manopt.org

Contact: manopttoolbox@gmail.com
