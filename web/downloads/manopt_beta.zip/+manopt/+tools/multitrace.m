function tr = multitrace(A)
% function tr = multitrace(A)
%
% For a 3-dimensional matrix A of size n-by-n-by-N, returns a vector tr of length N such that
% tr(k) = trace(A(:, :, k));
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    import manopt.tools.*;

	tr = diagsum(A, 1, 2);

end
