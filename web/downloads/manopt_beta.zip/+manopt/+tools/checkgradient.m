function checkgradient(problem, x, d)
% function checkgradient(problem)
% function checkgradient(problem, x)
% function checkgradient(problem, x, d)
%
% Numerical test to check that the gradient defined in the problem
% structure agree up to first order with the cost function, at some
% random point, along some random direction. It is also tested that the
% gradient is indeed a tangent vector. The point x and possibly also the
% direction d may be forced.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.tools.*;
    import manopt.privatetools.*;
    
    % Verify that the problem description is sufficient.
    if ~canGetCost(problem)
        error('It seems no cost was provided.');  
    end
    if ~canGetGradient(problem)
        error('It seems no gradient provided.');    
    end
    
    dbstore = struct();
    
    % If x and / or d are not specified, pick them at random.
    if ~exist('x', 'var') || isempty(x)
        x = problem.M.rand();
    end
    if ~exist('d', 'var') || isempty(d)
        d = problem.M.randvec(x);
    end
    
    %% Check that the gradient yields a first order model of the cost.
    
    % By removing the 'directional derivative' function, it should be so
    % (?) that the checkdiff function will use the gradient to compute
    % directional derivatives.
    if isfield(problem, 'diff')
        problem = rmfield(problem, 'diff');
    end
    checkdiff(problem, x, d);
    title(sprintf('Gradient check.\nThe slope of the continuous line should match that of the dashed (reference) line\nover at least a few orders of magnitude for h.'));
    xlabel('h');
    ylabel('Approximation error');
    
    %% Check that the gradient is a tangent vector.
    
    grad = getGradient(problem, x, dbstore);
    pgrad = problem.M.proj(x, grad);
    residual = problem.M.lincomb(x, 1, grad, -1, pgrad);
    err = problem.M.norm(x, residual);
    fprintf('The residual should be zero, or very close. Residual: %g.\n', err);
    fprintf('If it is far from 0, then the gradient is not in the tangent plane.\n');

end
