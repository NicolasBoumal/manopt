function checkhessian(problem, x, d)
% function checkhessian(problem)
% function checkhessian(problem, x)
% function checkhessian(problem, x, d)
%
% Numerical test to check that the directional derivatives and Hessian
% defined in the problem structure agree up to second order with the cost
% function, at some random point, along some random direction. We also
% check that the hessian along some direction is a tangent vector, and that
% the Hessian operator is symmetric w.r.t. the Riemannian metric. The point
% x and possibly also the direction d may be forced.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
        
    % Verify that the problem description is sufficient.
    if ~canGetCost(problem)
        error('It seems no cost was provided.');  
    end
    if ~canGetGradient(problem)
        error('It seems no gradient provided.');    
    end
    if ~canGetHessian(problem)
        error('It seems no Hessian was provided.');    
    end
    
    dbstore = struct();
    
    % If x and / or d are not specified, pick them at random.
    if ~exist('x', 'var') || isempty(x)
        x = problem.M.rand();
    end
    if ~exist('d', 'var') || isempty(d)
        d = problem.M.randvec(x);
    end
    
    %% Check that the directional derivative and the Hessian at x along d
    %% yield a second order model of the cost function.
    
    % Compute the value f0 at f, directional derivative df0 at x along d,
    % and Hessian along [d, d].
    f0 = getCost(problem, x, dbstore);
    df0 = getDirectionalDerivative(problem, x, d, dbstore);
    d2f0 = problem.M.inner(x, d, getHessian(problem, x, d, dbstore));
    
    % Compute the value of f at points on the geodesic (or approximation of
    % it) originating from x, along direction d, for stepsizes in a large
    % range given by h.
    h = logspace(-8, 0, 51);
    value = zeros(size(h));
    for i = 1 : length(h)
        y = problem.M.exp(x, d, h(i));
        value(i) = getCost(problem, y, dbstore);
    end
    
    % Compute the quadratic approximation of the cost function using f0,
    % df0 and d2f0 at the same points.
    model = polyval([.5*d2f0 df0 f0], h);
    
    % Compute the approximation error
    err = abs(model - value);
    
    % And plot it.
    loglog(h, err);
    title(sprintf('Hessian check.\nThe slope of the continuous line should match that of the dashed (reference) line\nover at least a few orders of magnitude for h.'));
    xlabel('h');
    ylabel('Approximation error');
    
    line('xdata', [1e-8 1e0], 'ydata', [1e-16 1e8], ...
         'color', 'k', 'LineStyle', '--', ...
         'YLimInclude', 'off', 'XLimInclude', 'off');
    
    % In a numerically reasonable neighborhood, the error should decrease
    % as the cube of the stepsize, ie, in loglog scale, the error should
    % have a slope of 3.
    mask = h >= 1e-2 & h <= 1e-1;
    P = polyfit(log10(h(mask)), log10(err(mask)), 1);
    fprintf('The slope should be 3. It is: %g.\n', P(1));
    fprintf('If it is far from 3, then directional derivatives or the Hessian might be erroneous.\n');

    
    %% Check that the Hessian at x along direction d is a tangent vector.
    hess = getHessian(problem, x, d, dbstore);
    phess = problem.M.proj(x, hess);
    residual = problem.M.lincomb(x, 1, hess, -1, phess);
    err = problem.M.norm(x, residual);
    fprintf('The residual should be zero, or very close. Residual: %g.\n', err);
    fprintf('If it is far from 0, then the Hessian is not in the tangent plane.\n');
    
    
    %% Check that the Hessian at x is symmetric.
    d1 = problem.M.randvec(x);
    d2 = problem.M.randvec(x);
    h1 = getHessian(problem, x, d1, dbstore);
    h2 = getHessian(problem, x, d2, dbstore);
    v1 = problem.M.inner(x, d1, h2);
    v2 = problem.M.inner(x, h1, d2);
    value = v1-v2;
    fprintf('<d1, H[d2]> - <H[d1], d2> should be zero, or very close.\n\tValue: %g - %g = %g.\n', v1, v2, value);
    fprintf('If it is far from 0, then the Hessian is not symmetric.\n');
    
end
