function A = multiscale(scale, A)
% function A = multiscale(scale, A)
%
% Given a vector scale of length N and a 3-dimensional matrix A of size
% n-by-m-by-N, returns a matrix A of same size such that
% A(:, :, k) := scale(k) * A(:, :, k);
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

	assert(length(size(A)) == 3);
	[n m N] = size(A);
	assert(numel(scale) == N);
	
% 	A = reshape(reshape(A, n*m, N) * spdiags(scale(:), 0, N, N), [n m N]);

    scale = scale(:);
    A = reshape(bsxfun(@times, reshape(A, n*m, N), scale'), n, m, N);

end
