function [x cost info] = steepestdescent(problem, x, options)
% function [x cost info] = steepestdescent(problem, x, options)
%
% Apply the steepest descent minimization algorithm to the problem defined
% in the problem structure, starting at x if it is provided (otherwise, at
% a random point on the manifold). To specify options whilst not specifying
% an initial guess, give x as [] (the empty matrix).
%
% None of the options are mandatory. See the documentation for details.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
    import manopt.solvers.steepestdescent.*;
    
    % Verify that the problem description is sufficient for the solver.
    if ~canGetCost(problem)
        warning('manopt:getCost', ...
                'No cost provided. The algorithm will likely abort.');  
    end
    if ~canGetGradient(problem)
        warning('manopt:getGradient', ...
                'No gradient provided. The algorithm will likely abort.');    
    end

    % Set local defaults here
    localdefaults.minstepsize = 1e-10;
    localdefaults.maxiter = 1000;
    localdefaults.tolgradnorm = 1e-6;
    localdefaults.linesearch = @linesearch;
    
    % Merge global and local defaults, then merge w/ user options, if any.
    localdefaults = mergeOptions(getGlobalDefaults(), localdefaults);
    if ~exist('options', 'var') || isempty(options)
        options = struct();
    end
    options = mergeOptions(localdefaults, options);
    
    % Create a store database
    storedb = struct();
    
    timetic = tic();
    
    % If no initial point x is given by the user, generate one at random.
    if ~exist('x', 'var') || isempty(x)
        x = problem.M.rand();
    end
    
    % Compute objective-related quantities for x
    [cost storedb] = getCost(problem, x, storedb);
    [grad storedb] = getGradient(problem, x, storedb);
    gradnorm = problem.M.norm(x, grad);
    
    % Iteration counter (at any point, iter is the number of fully executed
    % iterations so far)
    iter = 0;
    
    % Save stats in a struct array info, and preallocate
    % (see http://people.csail.mit.edu/jskelly/blog/?x=entry:entry091030-033941)
    stats = savestats();
    info(1) = stats;
    info(min(10000, options.maxiter+1)).iter = [];
    
    % Initial linesearch memory
    lsmem = [];
    
    if options.verbosity >= 1
        fprintf(' iter\t    cost val\t grad. norm\n');
    end
    
    % Start iterating until stopping criterion triggers
    while true

        % Display iteration information
        if options.verbosity >= 1
            fprintf('%5d\t%+.4e\t%.4e\n', iter, cost, gradnorm);
        end
        
        % Start timing this iteration
        timetic = tic();
        
        % Run standard stopping criterion checks
        [stop reason] = stoppingcriterion(problem, x, options, info, iter+1);
        
        % Run specific stopping criterion check
        if ~stop && stats.stepsize < options.minstepsize
            stop = true;
            reason = 'Last stepsize smaller than minimum allowed.';
        end
    
        if stop
            if options.verbosity >= 1
                fprintf([reason '\n']);
            end
            break;
        end

        % Compute a normalized descent direction
        desc_dir = problem.M.lincomb(x, -1/gradnorm, grad);
        
        % Execute line-search (TODO: this is not a good one)
        % TODO: give linesearch the opportunity to return statistics
        % (stepsize, number of trials etc)
        [stepsize newx storedb lsmem] = ...
         options.linesearch(problem, x, desc_dir, options, storedb, lsmem);
        
        % Compute the new objective-related quantities for x
        [newcost storedb] = getCost(problem, newx, storedb);
        [newgrad storedb] = getGradient(problem, newx, storedb);
        newgradnorm = problem.M.norm(newx, newgrad);
        
        % Make sure we don't use to much memory for the store database
        % TODO: discuss moving this to getCost, getGradient etc.
        %       will require passing them storedepth.
        storedb = purgeStoredb(storedb, options.storedepth);
        
        % Update iterate info
        x = newx;
        cost = newcost;
        grad = newgrad;
        gradnorm = newgradnorm;
        
        % iter is the number of iterations we have accomplished.
        iter = iter + 1;
        
        % Log statistics for freshly executed iteration
        stats = savestats();
        info(iter+1) = stats; %#ok<AGROW>
        
    end
    
    
    info = info(1:iter+1);

    if options.verbosity >= 1
        fprintf('Total time is %f [s] (excludes statsfun)\n', info(end).time);
    end
    
    
    
    % Routine in charge of collecting the current iteration stats
    function stats = savestats()
        stats.iter = iter;
        stats.cost = cost;
        stats.gradnorm = gradnorm;
        if iter == 0
            stats.stepsize = nan;
            stats.time = toc(timetic);
        else
            stats.stepsize = stepsize;
            stats.time = info(iter).time + toc(timetic);
        end
        if isfield(options, 'statsfun')
            stats = options.statsfun(problem, x, stats);
        end
    end
    
end
