function [stepsize newx storedb lsmem] = linesearch(problem, x, d, options, storedb, lsmem)
% function [stepsize newx storedb lsmem] = linesearch(problem, x, d, options, storedb, lsmem)
%
% First attempt at a crude linesearch algorithm for steepest descent.
% Based on a simple backtracking method.
% TODO: implement nice linesearchs from Nocedal&Wright (pp 56 sq.)
% TODO: rename this with explicit reference to the type of algorithm in use
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;

    % Backtracking parameters (TODO: give control over this via options)
    contraction_factor = .5;
    suff_decr = 1e-4;
    max_ls_steps = 10;

    % Compute the cost and derivative of the line search function at 0.
    [f0 storedb] = getCost(problem, x, storedb);
    [df0 storedb] = getDirectionalDerivative(problem, x, d, storedb);
    
    % Perhaps a smart initial guess for the step size: N&W, p59.
    if ~isempty(lsmem)
        % pick initial stepsize based on where we were last time
        stepsize = 2*(f0-lsmem.f0)/df0;
        % and go look a little further, just in case.
        stepsize = stepsize / contraction_factor;
        % in case this gave a zero stepsize, try to force a larger one
        if stepsize <= eps
            stepsize = abs(df0);
        end
    else
        stepsize = 1;
    end
    for i = 1 : max_ls_steps
        
        % Look further down the line
        newx = problem.M.retr(x, d, stepsize);
        [newf storedb] = getCost(problem, newx, storedb);
        
        % If that point is not satisfactory, reduce the stepsize and retry.
        if newf > f0 + suff_decr*stepsize*df0
            stepsize = contraction_factor * stepsize;
            
        % Otherwise, stop here.
        else
            break;
        end
        
    end
    
    % If we executed max_ls_steps without obtaining a decrease,
    % we simply reject the step.
    if newf > f0
        stepsize = 0;
        newx = x;
    end

    % Save the situtation faced now so that at the next iteration, we will
    % know something about the previous decision.
    lsmem.f0 = f0;
    lsmem.df0 = df0;
    lsmem.stepsize = stepsize;
    
end
