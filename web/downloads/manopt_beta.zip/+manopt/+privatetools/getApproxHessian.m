function [hess, storedb] = getApproxHessian(problem, x, d, storedb)
% function [hess, storedb] = getApproxHessian(problem, x, d, storedb)
%
% Return an approximation of the Hessian at x along d of the cost function
% described in the problem structure. The cache database storedb is passed
% along, possibly modified and returned in the process.
% The approximation may be user-specified, or a standard approximation from
% the toolbox, based on other user-specified quantities.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
    
    % TODO: for now, we only have this; but later, we can have
    % user-speicifed approximations of the Hessian too, that will get
    % precedence over this.
    [hess, storedb] = getHessianFD(problem, x, d, storedb);
    
end
