function candoit = canGetCost(problem)
% function candoit = canGetCost(problem)
%
% Returns true if the cost function can be computed given the problem
% description, false otherwise.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    candoit = isfield(problem, 'cost');
    
end
