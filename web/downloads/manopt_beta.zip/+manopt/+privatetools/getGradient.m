function [grad, storedb] = getGradient(problem, x, storedb)
% function [grad, storedb] = getGradient(problem, x, storedb)
%
% Return the gradient at x of the cost function described in the problem
% structure. The cache database storedb is passed along, possibly modified
% and returned in the process.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
    
    if isfield(problem, 'grad')
    %% Compute the gradient using grad
        
        % Check whether the gradient function wants to deal with the store
        % structure or not
        switch nargin(problem.grad)
            case 1
                grad = problem.grad(x);
            case 2
                % Obtain, pass along, and save the store structure
                % associated to this point.
                store = getStore(problem, x, storedb);
                [grad store] = problem.grad(x, store);
                storedb = setStore(problem, x, storedb, store);
            otherwise
                up = MException('manopt:getGradient:badgrad', ...
                    'grad should accept 1 or 2 inputs.');
                throw(up);
        end      

    else
    %% Abandon computing the gradient
    
        up = MException('manopt:getGradient:fail', ...
            ['The problem description is not explicit enough to ' ...
             'compute the gradient of the cost.']);
        throw(up);
        
    end
    
end
