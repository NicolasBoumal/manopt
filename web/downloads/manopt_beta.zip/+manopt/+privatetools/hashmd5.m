function h = hashmd5(inp)
% Returns a string containing the MD5 hash of the input variable.
% This code is a stripped version of more general hashing code by Michael
% Kleder, Nov 2005.
%
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    inp=inp(:);
    % convert strings and logicals into uint8 format
    if ischar(inp) || islogical(inp)
        inp=uint8(inp);
    else % convert everything else into uint8 format without loss of data
        inp=typecast(inp,'uint8');
    end

    % create hash
    x = java.security.MessageDigest.getInstance('MD5');
    x.update(inp);
    h = typecast(x.digest, 'uint8');
    h = dec2hex(h)';
    if(size(h,1))==1 % remote possibility: all hash bytes < 128, so pad:
        h = [repmat('0',[1 size(h,2)]);h];
    end
    h = lower(h(:)');
    clear x
	
end