function storedb = setStore(problem, x, storedb, store)
% function storedb = setStore(problem, x, storedb, store)
%
% Update the storedb database of structures such that the structure
% corresponding to the point x will be replaced by store.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE
   
    % Construct the fieldname (key) associated to the current point x.
    key = problem.M.hash(x);
    
    % Set the value associated to that key to store.
    storedb.(key) = store;
    
    % Add / update a last-set flag
    storedb.(key).lastset = cputime();

end