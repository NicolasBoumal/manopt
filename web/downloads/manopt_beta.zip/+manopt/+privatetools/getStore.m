function store = getStore(problem, x, storedb)
% function store = getStore(problem, x, storedb)
%
% Query the storedb database of structures and return the store structure
% corresponding to the point x.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE
   
    % Construct the fieldname (key) associated to the current point x.
    key = problem.M.hash(x);
    
    % If there is a value stored for this key, return it.
    % Otherwise, return an empty structure.
    if isfield(storedb, key)
        store = storedb.(key);
    else
        store = struct();
    end

end
