function [hess, storedb] = getHessian(problem, x, d, storedb)
% function [hess, storedb] = getHessian(problem, x, d, storedb)
%
% Return the Hessian at x along d of the cost function described in the
% problem structure. The cache database storedb is passed along, possibly
% modified and returned in the process.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
    
    if isfield(problem, 'hess')
    %% Compute the Hessian using hess
        
        % Check whether the Hessian function wants to deal with the store
        % structure or not
        switch nargin(problem.hess)
            case 2
                hess = problem.hess(x, d);
            case 3
                % Obtain, pass along, and save the store structure
                % associated to this point.
                store = getStore(problem, x, storedb);
                [hess store] = problem.hess(x, d, store);
                storedb = setStore(problem, x, storedb, store);
            otherwise
                up = MException('manopt:getHessian:badhess', ...
                    'hess should accept 2 or 3 inputs.');
                throw(up);
        end
        
    else
    %% Attempt the computation of an approximation of the Hessian
        
        [hess, storedb] = getApproxHessian(problem, x, d, storedb);
        
    end
    
end
