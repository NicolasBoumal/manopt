function [hess, storedb] = getHessianFD(problem, x, d, storedb)
% function [hess, storedb] = getHessianFD(problem, x, d, storedb)
%
% Return a finite-difference approximation of the Hessian at x along d of
% the cost function described in the problem structure. The cache database
% storedb is passed along, possibly modified and returned in the process.
%
% TODO: reference paper and mention guarantees (radial linearity, up to sign)
% TODO: how do we give the user control over the step parameter?
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    % Import necessary tools etc. here
    import manopt.privatetools.*;
    
    % First, check whether the step d is not too small
    if problem.M.norm(x, d) < eps
        hess = problem.M.zerovec(x);
        return;
    end
    
    % Parameter: how far do we look? TODO: give the user control over this.
    epsilon = 1e-4;
        
    % TODO: deal with the sign
    % sg = sign(d(find(d(:), 1, 'first')));
    sg = 1;
    norm_d = problem.M.norm(x, d);
    c = epsilon*sg/norm_d;
    
    % Gradient here
    [grad0 storedb] = getGradient(problem, x, storedb);
    
    % Point and gradient a little further along d
    x1 = problem.M.retr(x, d, c);
    [grad1 storedb] = getGradient(problem, x1, storedb);
    
    % Crudely transport grad1 back from x1 to x.
    grad1 = problem.M.transp(x1, x, grad1);
    
    % Finite difference of them
    hess = problem.M.lincomb(x, 1/c, grad1, -1/c, grad0);
    
end
