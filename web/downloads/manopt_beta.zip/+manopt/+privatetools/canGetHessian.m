function candoit = canGetHessian(problem)
% function candoit = canGetHessian(problem)
%
% Returns true if the Hessian of the cost function can be computed given
% the problem description, false otherwise.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    candoit = isfield(problem, 'hess');
    
end
