function candoit = canGetDirectionalDerivative(problem)
% function candoit = canGetDirectionalDerivative(problem)
%
% Returns true if the directional derivatives of the cost function can be
% computed given the problem description, false otherwise.
%
% INSERT_END_OF_COMMENTS_NOTICE_HERE

    candoit = isfield(problem, 'diff') || isfield(problem, 'grad');
    
end
